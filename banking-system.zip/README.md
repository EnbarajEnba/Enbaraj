# Banking Management System (Spring Boot)

## Defaults used
- MySQL user: `root`
- MySQL password: (empty)
- Database: `banking_system`
- API base: `http://localhost:8080/api`

## How to run

1. Create the database (in MySQL):
   ```sql
   CREATE DATABASE banking_system;
   ```

2. Start MySQL server and ensure `root` user has empty password (or update `src/main/resources/application.properties`).

3. Build and run:
   ```bash
   mvn spring-boot:run
   ```

4. Open the frontend:
   - Visit `http://localhost:8080` to view the provided static HTML frontend.

## Notes
- This project is minimal and intended for local development/testing.
- For production: secure DB credentials, enable HTTPS, add validation, authentication, and proper error handling.
