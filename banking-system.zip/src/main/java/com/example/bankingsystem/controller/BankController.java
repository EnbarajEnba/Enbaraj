package com.example.bankingsystem.controller;

import com.example.bankingsystem.model.Account;
import com.example.bankingsystem.service.BankService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class BankController {
    private final BankService bankService;

    public BankController(BankService bankService) {
        this.bankService = bankService;
    }

    @PostMapping("/accounts")
    public Account createAccount(@RequestParam String name, @RequestParam double deposit) {
        return bankService.createAccount(name, deposit);
    }

    @PostMapping("/deposit/{id}")
    public String deposit(@PathVariable UUID id, @RequestParam double amount) {
        bankService.deposit(id, amount);
        return "Deposit successful";
    }

    @PostMapping("/withdraw/{id}")
    public String withdraw(@PathVariable UUID id, @RequestParam double amount) {
        bankService.withdraw(id, amount);
        return "Withdrawal successful";
    }

    @PostMapping("/transfer")
    public String transfer(@RequestParam UUID from, @RequestParam UUID to, @RequestParam double amount) {
        bankService.transfer(from, to, amount);
        return "Transfer successful";
    }

    @GetMapping("/accounts")
    public List<Account> listAccounts() {
        return bankService.listAccounts();
    }

    @GetMapping("/accounts/{id}")
    public Account getAccount(@PathVariable UUID id) {
        return bankService.getAccount(id);
    }
}
