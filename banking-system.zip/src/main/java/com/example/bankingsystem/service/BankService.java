package com.example.bankingsystem.service;

import com.example.bankingsystem.model.Account;
import com.example.bankingsystem.model.Transaction;
import com.example.bankingsystem.repo.AccountRepository;
import com.example.bankingsystem.repo.TransactionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
public class BankService {
    private final AccountRepository accountRepo;
    private final TransactionRepository txRepo;

    public BankService(AccountRepository accountRepo, TransactionRepository txRepo) {
        this.accountRepo = accountRepo;
        this.txRepo = txRepo;
    }

    public Account createAccount(String name, double deposit) {
        Account acc = new Account(name, deposit);
        accountRepo.save(acc);
        if (deposit > 0) {
            for (Transaction t : acc.getTransactions()) {
                txRepo.save(t);
            }
        }
        return acc;
    }

    @Transactional
    public void deposit(UUID id, double amount) {
        Account acc = accountRepo.findById(id).orElseThrow(() -> new RuntimeException("Account not found"));
        if (amount <= 0) throw new RuntimeException("Amount must be positive");
        acc.setBalance(acc.getBalance() + amount);
        Transaction t = new Transaction("DEPOSIT", amount, "Deposit", acc);
        acc.getTransactions().add(t);
        txRepo.save(t);
        accountRepo.save(acc);
    }

    @Transactional
    public void withdraw(UUID id, double amount) {
        Account acc = accountRepo.findById(id).orElseThrow(() -> new RuntimeException("Account not found"));
        if (amount <= 0) throw new RuntimeException("Amount must be positive");
        if (acc.getBalance() < amount) throw new RuntimeException("Insufficient funds");
        acc.setBalance(acc.getBalance() - amount);
        Transaction t = new Transaction("WITHDRAW", amount, "Withdrawal", acc);
        acc.getTransactions().add(t);
        txRepo.save(t);
        accountRepo.save(acc);
    }

    @Transactional
    public void transfer(UUID from, UUID to, double amount) {
        if (from.equals(to)) throw new RuntimeException("Source and destination cannot be the same");
        withdraw(from, amount);
        deposit(to, amount);
    }

    public List<Account> listAccounts() {
        return accountRepo.findAll();
    }

    public Account getAccount(UUID id) {
        return accountRepo.findById(id).orElse(null);
    }
}
