package com.example.bankingsystem.model;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "accounts")
public class Account {
    @Id
    private UUID id;

    private String ownerName;
    private double balance;
    private Instant createdAt;

    @OneToMany(mappedBy = "account", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<Transaction> transactions = new ArrayList<>();

    public Account() {
        this.id = UUID.randomUUID();
        this.createdAt = Instant.now();
        this.balance = 0.0;
        this.ownerName = "Unknown";
    }

    public Account(String ownerName, double initialDeposit) {
        this();
        this.ownerName = ownerName == null ? "Unknown" : ownerName;
        this.balance = Math.max(0.0, initialDeposit);
        if (initialDeposit > 0) {
            Transaction t = new Transaction("DEPOSIT", initialDeposit, "Initial deposit", this);
            this.transactions.add(t);
        }
    }

    public UUID getId() { return id; }
    public String getOwnerName() { return ownerName; }
    public void setOwnerName(String ownerName) { this.ownerName = ownerName; }
    public double getBalance() { return balance; }
    public void setBalance(double balance) { this.balance = balance; }
    public Instant getCreatedAt() { return createdAt; }
    public List<Transaction> getTransactions() { return transactions; }
}
